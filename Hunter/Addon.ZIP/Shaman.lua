-- VERSion 1.89
local Healingbuffs =  "Riptide"
local interruptable = {
	198931, -- Healing Light(valor)
	198962, -- Shattered Rune (valor)
	192563, --Cleansing Flames(valor)
	192288, -- Searing Light(valor)
	199726,	-- Unruly Yell(valor)
	-- maw of Souls
	194657, --soul-siphon
	199514, --torrent-of-souls
	198405, -- bone-chilling-scream
	194266, --void-snap
	195293, --debilitating-shout
	198495, --torrent
	-- nelthslair
	202181, --stone-gaze
	193585, --bound
	-- return to kara
	232115, --firelands-portal
	228255, --soul-leech
	228239, --terrifying-wail
	227917, --poetry-slam
	228280, --oath-of-fealty
	226316, --shadow-bolt-volley
	228625, --banshee-wail
	227823, --holy-wrath
	227800, --holy-shock
	227545, --mana-drain
	227616, --empowered-arms
	227542, --smite
	228606, --healing-touch
	229307, --reverberating-shadows
	227628, --piercing-missiles
	227592, --frostbite
	229714, --consume-magic
	229083, --burning-blast
	-- arcway
	210684, --siphon-essence
	211007, --eye-of-the-vortex
	226285, --demonic-ascension
	211757, --portal-argus
	211917, --felstorm
	226206, --arcane-reconstitution
	211115, --phase-breach
	196392, --overcharge-mana
	203176, --accelerating-blast
	203957, --time-lock
	193069, --nightmares
	191823, --furious-blast
	200905, --sap-soul
	201488, --frightening-shout
	195332, --sear
	-- eye of azura
	196870, --storm
	218532, --arc-lightning
	195046, --rejuvenating-waters
	195129, --thundering-stomp
	197502, --restoration
	192135, --bellowing-roar
	196027, --aqua-spout
	196175, --armorshell
	192003, --blazing-nova
	191848, --rampage
	-- violet hold
	205112, --drain-essence
	205121, --chaos-bolt
	224460, --venom-nova
	204963, --shadow-bolt-volley
	-- black rook hold
	225573, --dark-mending
	196883, --spirit-blast
	200248, --arcane-blitz
	-- court of stars
	210261, --sound-alarm
	209485, --drain-magic
	209404, --seal-magic
	209413, --suppress
	225100, --charging-station
	215204, --hinder
	211299, --searing-glare
	212784, --eye-storm
	211470, --bewitch
	211401, --drifting-embers
	211464, --fel-detonation
	208165, --withering-soul
	--dark heart thicket
	200658, --star-shower
	204246, --tormenting-fear
	201400, --dread-inferno
		-- emerald nightmares
	211368, --twisted-touch-of-life
	-- night hold
	225412, --mass-siphon
	224568, --mass-suppress
	224515, --warped-blast
	224488, --reverse-wounds
	225047, --shrink
	213281, --pyroblast
	225809, --time-reversal
	221464, --chaotic-energies
	209017, --felblast
	224943, --eradication
	224944, --will-of-the-legion
	225410, --withering-volley
	207228, --warp-nightwell
	214181, --slop-burst
	226231, --faint-hope
	221864, --blast
	209568, --exothermic-release
	209971, --ablative-pulse
}
local stopcast = 
{
	199726, -- Unruly Yell(valor)
	227363, --mighty-stomp
	--arcway
	191527, --deafening-shout
}

local stopHealingdebuff =
{
	228796, --ignite-soul
}
local usedefensive =
{
	--black rook hold
	202019, --shadow-bolt-volley
	194266, --void-snap
	--night hold
	206936, --icy-ejection
	207143, --void-ejection
	225845, --chosen-fate
}
local usestuns =
{
	--court
	212784, --eye-storm
	211464, --fel-detonation
	-- vault
	202658, --drain
	--arcway
	210868, --arcane-barrier
	--nelfthain lair
	193803, --metamorphosis
	--night hold
	225407, --mournful-howl
}

local Race = {
	["Human"] = 0.01,
	["Dwarf"]= 0.02,
	["nightelf"]= 0.03,
	["Gnome"]= 0.04,
	["Draenei"]= 0.05,
	["Pandaren"]= 0.06,
	["Orc"]= 0.07,
	["Undead"]= 0.08,
	["Tauren"]= 0.09,
	["Troll"]= 0.10,
	["Blood Elf"]= 0.11,
	["Goblin"]= 0.12,
}
local Spec = {
	["Blood"] = 0.01,
	["Frost"] = 0.02,
	["Unholy"] =0.03,
	["Havoc"] = 0.04,
	["Vengeance"] =0.05,
	["Balance"] = 0.06,
	["Feral"] =0.07,
	["Guardian"] =0.08,
	["Restoration"] =0.09,
	["Beast Mastery"] = 0.10,
	["Marksmanship"] =0.11,
	["Survival"] = 0.12,
	["Arcane"] =0.13,
	["Fire"] = 0.14,
	["Frost"] =0.15,
	["Brewmaster"] = 0.16,
	["Mistweaver"] =0.17,
	["Windwalker"] = 0.18,
	["Holy"] = 0.19,
	["Protection"] = 0.20,
	["Retribution"] =0.21,
	["Discipline"] = 0.22,
	["HolyPriest"]=.23,
	["Shadow"] =0.24,
	["Assassination"] =0.25,
	["Outlaw"] =0.26,
	["Subtlety"] = 0.27,
	["Elemental"] = 0.28,
	["Enhancement"] = 0.29,
	["RestorationShaman"] = 0.30,
	["Affliction"] = 0.31,
	["Arms"] = 0.32,
	["Fury"] = 0.33,
	["Protection"] = 0.34,
	["Demonology"] = 0.35,
    ["Destruction"] = 0.36,
}

local activeUnitPlates = {}
local RaidBuffFrame = {}
local raidSizeFrame = nil
local PlayerStatFrame = {}
local targetCastFrame = nil
local targetCasting = nil
local PlatesOn = 0
local party_units = {}
local raid_units = {}
local raidheal_cache = {}
local raidHealthFrame = {}
local RaidRole = {}
local RaidRange = {}
local lasthp = {}
local castPCT = 0
local castType = 0
local lastCastID = nil
local nameplatelast = 0
local charUnit = {}
local Tier = {}
local lasthaste = 0
local hasteInfo = {}
local raidBuff = {}
local raidBufftime = {}
local partySize = 0

local frame = CreateFrame("frame", "", parent)
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterUnitEvent("UNIT_SPELLCAST_START","target")
frame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", "target")
frame:RegisterUnitEvent("UNIT_SPELLCAST_STOP","target")
frame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "target")
frame:RegisterEvent("UNIT_HEALTH_FREQUENT")
frame:RegisterEvent("RAID_ROSTER_UPDATE")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterUnitEvent("UNIT_SPELL_HASTE","player")
frame:RegisterUnitEvent("UNIT_POWER","player")
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
local EnterWorld= false

local function targetStopCast()
	if(castType ~= nil) then
		for _, value in pairs(stopcast) do
			if value == targetCasting then
				castType = .30
			end
		end
	end
end
local function HasteInfoUpdate()
	local ratingBonus = math.floor(GetHaste())
	if lasthaste == ratingBonus then return end
	lastehaste = ratingBonus
	hasteInfo[2] = 0
	if (ratingBonus * -1) > ratingBonus then
		HasteInfo[2] = 1
	end
	hasteInfo[1] = tonumber("0.0".. math.abs(ratingBonus))
	if (math.abs(ratingBonus) >= 10) then
		hasteInfo[1] = tonumber("0.".. math.abs(ratingBonus))
	end

end
local function UpdateMana()
		local Mana = UnitPower("player",0)
		local maxMana = UnitPowerMax("player",0)
		charUnit[1] = Mana / maxMana
		HasteInfoUpdate()
		PlayerStatFrame[4].t:SetColorTexture(hasteInfo[2], hasteInfo[1],charUnit[1], alphaColor)
end
local function targetDefensive()
	if(castType ~= nil) then
		for _, value in pairs(usedefensive) do
			if value == targetCasting then
				castType = .40
			end
		end
	end
end
local function targetStun()
	if(castType ~= nil) then
		for _, value in pairs(usestuns) do
			if value == targetCasting then
				castType = .50
			end
		end
	end
end

local function addtargetcast(spellID)
	local notInterruptible = select(9, UnitCastingInfo("target"))
	if(select(8,UnitCastingInfo("target")) == nil) then
		notInterruptible = select(9, UnitChannelInfo("target"))
	end
	if notInterruptible == false then
		castType = .10
		for _, value in pairs(interruptable) do
			if  value == targetCasting then
				castType = .20

			end
		end
	end
	targetCasting = spellID
	targetStopCast()
	targetDefensive()
	targetStun()
	--print("Is spell interruptable: ", notInterruptible)
	--print("Casting type : ", castType, "Casting PCT ",castPCT )
	targetCastFrame.t:SetColorTexture(castType, castPCT, 0, alphaColor)
end
local function removetargetcast(spellID)
		castPCT = 0
		castType = 0
		lastCastID = nil

		targetCastFrame.t:SetColorTexture(castType, castPCT, 0, alphaColor)
		--print("Remove cast event fired ID: ",spellID)
		targetCasting = nil
end

local function InteruptSpellTime(startTime, endTime)
	local remainingTime = math.abs(endTime - GetTime()*1000)
	local CastTime = math.abs(endTime - startTime)/100
	castPCT= math.ceil(remainingTime/CastTime)/100
	--print("Cast time: ", castTime, "Cast PCT: ",castPCT,"remaining :", remainingTime)
end

local function targetCastingupdate(self, event)
	if	lastCastID ~= nil then
		local startTime = select(5,UnitCastingInfo("target"))
		local endTime = select(6,UnitCastingInfo("target") )
		local castID = select(8,UnitCastingInfo("target") )
		if(castID == nil) then
			startTime = select(5,UnitChannelInfo("target"))
			endTime = select(6,UnitChannelInfo("target") )
		end

		InteruptSpellTime(startTime, endTime)
		--print("Last Casting type : ", castType, "Casting PCT ",castPCT )
		targetCastFrame.t:SetColorTexture(castType, castPCT, 0, alphaColor)
	
	end
end

local function Talents()
		local AllSeven = false
		for i = 1, GetMaxTalentTier() do 
		local talenetSelected = false
			for z = 1, 3 do 
				local  selected = select(4, GetTalentInfo(i, z,1))
				if(selected == true) then
					Tier[i] = z/100
					talenetSelected = true
				end
				if talenetSelected == false and z == 3 then
					Tier[i]=0
					print("(None selected)T",i ," set to 0")
				end
			end
			if i == 7 then
				AllSeven = true 
			end
		end
	if not AllSeven then
		for i = GetMaxTalentTier(), 7 do
			print("(lowLevel T",i ," set to 0")
			Tier[i] = 0	
		end
	end
	print(" T1 ", Tier[1]," T2 ",Tier[2], " T3 ",Tier[3]," T4 ",Tier[4]," T5 ",Tier[5]," T6 ",Tier[6]," T7 ",Tier[7]);
    
	PlayerStatFrame[1].t:SetColorTexture(Tier[1], Tier[2],Tier[3], alphaColor)
	PlayerStatFrame[2].t:SetColorTexture(Tier[4],Tier[5],Tier[6], alphaColor)
	PlayerStatFrame[3].t:SetColorTexture(Tier[7],charUnit[3],charUnit[2], alphaColor)
	       
	
end
-- populate unit tables
local function CharRaceUpdate()
	local unitSpec = select(2, GetSpecializationInfo(GetSpecialization()))
	charUnit[2] = Race[UnitRace("player")]
	charUnit[3] = Spec[unitSpec]
	print(charUnit[3],charUnit[2])

end


local function UnitIsPartyUnit(unit)
	for _, v in next, party_units do
		if unit == v then return true end
	end
end

local function UnitIsRaidUnit(unit)
	for _, v in next, raid_units do
		if unit == v then return true end
	end
end

local function HealthChangedEvent(unit)
	local h = UnitHealth(unit)
	if h==lasthp[unit] then return end
	lasthp[unit]=h
	local m = UnitHealthMax(unit);
	h = (h / m)
	raidheal_cache[unit] = h
end

local function RangeCheck(unit)
	if LibStub("SpellRange-1.0").IsSpellInRange("Healing Wave", unit) == 1 then
		RaidRange[unit] = 1;
	else
		RaidRange[unit] = .5;
	end
end

local function RaidRoleCheck(unit)
	if UnitGroupRolesAssigned(unit) == "TANK" then
		RaidRole[unit] = 1;
	elseif UnitGroupRolesAssigned(unit) == "HEALER" then
		RaidRole[unit] = .5;
	else
		RaidRole[unit] = 0;
	end
end

local function UpdateRaidIndicators(unit)
	
	if UnitIsRaidUnit(unit) or UnitIsPartyUnit(unit) then
		if UnitInParty ("player")  and not UnitInRaid ("player")then 
			for i, key in pairs(party_units) do
				if key == unit then
					HealthChangedEvent(unit)
					RangeCheck(unit)
					RaidRoleCheck(unit)
					--print(unit, "is at :", raidheal_cache[unit])
					raidHealthFrame[i].t:SetColorTexture(raidheal_cache[unit], RaidRange[unit], RaidRole[unit], alphaColor)
				end	
			end
		end
		if UnitInRaid ("player") then 
			for i, key in pairs(raid_units) do
				if key == unit then
					HealthChangedEvent(unit)
					RangeCheck(unit)
					RaidRoleCheck(unit)
					--print(unit, "is at :", raidheal_cache[unit])
					raidHealthFrame[i].t:SetColorTexture(raidheal_cache[unit], RaidRange[unit], RaidRole[unit], alphaColor)
				end	
			end
		end
		if not UnitInRaid ("player") and not UnitInParty ("player") then
			for i = 1, 30 do
				raidHealthFrame[i].t:SetColorTexture(1, 0, 0, alphaColor)
			end
		end
	end
end

local function UpdateRaidBuffIndicators(unit)
		select(7, UnitBuff(unit, Healingbuffs, "player"))
		if expires == nil  then return end
		UpdateRaidBuffslot(unit,expires)
end

local function UpdateRaidBuffslot(unit,expires)
	for i = 1, 4 do 
		if raidBuff[i] == 0 then
			local slot = string.match (unit, "%d+")
			UpdateBuffTime(unit,expires,i)
			if i >= 10 then
				raidBuff[i] = tonumber("0." .. slot)
			else 
				raidBuff[i] = tonumber("0.0" .. slot)
			end
		end
	end
end

local function UpdateBuffTime(unit,expires,location)
	local getTime = GetTime()
	local remainingTime = math.floor(expires - getTime + 0.5)
	if(remainingTime >= 10) then
		raidBufftime[i] = tonumber("0."..remainingTime);
	else
		raidBufftime[i] = tonumber("0.0"..remainingTime);
	end
end

local function updateRaidBuff(self, event)
	if not UnitInRaid ("player") and  UnitInParty ("player") then
		for key, _ in pairs(party_units) do
			UpdateRaidBuffIndicators(key)
		end
	end	
	if UnitInRaid ("player") then
		for key, _ in pairs(raid_units) do
			UpdateRaidBuffIndicators(key)
		end
	end
	for i=1, 4 do 
		if raidBuff[i] ~= nil then
			RaidBuffFrame[i].t:SetColorTexture(raidBuff[i], 1, raidBufftime[i], alphaColor)
			RaidBuffFrame[i].t:SetAllPoints(false)
		else
			RaidBuffFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
			RaidBuffFrame[i].t:SetAllPoints(false)
			raidBuff[i] = nil
			raidBufftime[i] = nil
		end
	end
end
local function TurnOnPlates()
	if GetCVar("nameplateShowEnemies") == "1" then
		PlatesOn = 1
	else
		PlatesOn = 0
	end
end
local enemiesPlate = 0
local function activeEnemies()
    enemiesPlate = 0
    for k, v in pairs(activeUnitPlates) do
        if v ~= nil then
            if UnitCanAttack("player", k) 
            and (LibStub("SpellRange-1.0").IsSpellInRange("Death Strike", k) == 1 and charUnit[3] == .01 or
			LibStub("SpellRange-1.0").IsSpellInRange("Frost Strike", k) == 1 and charUnit[3] == .02 or
			LibStub("SpellRange-1.0").IsSpellInRange("Festering Strike", k) == 1 and charUnit[3] == .03 or
			LibStub("SpellRange-1.0").IsSpellInRange("Demon's Bite", k) == 1 and charUnit[3] == .04 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shear", k) == 1 and charUnit[3] == .05 or
			LibStub("SpellRange-1.0").IsSpellInRange("Solar Wrath", k) == 1 and charUnit[3] == .06 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shred", k) == 1 and charUnit[3] == .07 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mangle", k) == 1 and charUnit[3] == .08 or
			LibStub("SpellRange-1.0").IsSpellInRange("Solar Wrath", k) == 1 and charUnit[3] == .09 or
			LibStub("SpellRange-1.0").IsSpellInRange("Counter Shot", k) == 1 and charUnit[3] == .10 or
			LibStub("SpellRange-1.0").IsSpellInRange("Counter Shot", k) == 1 and charUnit[3] == .11 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mongoose Bite", k) == 1 and charUnit[3] == .12 or
			LibStub("SpellRange-1.0").IsSpellInRange("Arcane Blast", k) == 1 and charUnit[3] == .13 or
			LibStub("SpellRange-1.0").IsSpellInRange("Fireball", k) == 1 and charUnit[3] == .14 or
			LibStub("SpellRange-1.0").IsSpellInRange("Frostbolt", k) == 1 and charUnit[3] == .15 or
			LibStub("SpellRange-1.0").IsSpellInRange("Blackout Strike", k) == 1 and charUnit[3] == .16 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rising Sun Kick", k) == 1 and charUnit[3] == .17 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rising Sun Kick", k) == 1 and charUnit[3] == .18 or
			LibStub("SpellRange-1.0").IsSpellInRange("Crusader Strike", k) == 1 and charUnit[3] == .19 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shield of the Righteous", k) == 1 and charUnit[3] == .20 or
			LibStub("SpellRange-1.0").IsSpellInRange("Crusader Strike", k) == 1 and charUnit[3] == .21 or
			LibStub("SpellRange-1.0").IsSpellInRange("Penance", k) == 1 and charUnit[3] == .22 or
			LibStub("SpellRange-1.0").IsSpellInRange("Smite", k) == 1 and charUnit[3] == .23 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mind Blast", k) == 1 and charUnit[3] == .24 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mutilate", k) == 1 and charUnit[3] == .25 or
			LibStub("SpellRange-1.0").IsSpellInRange("Saber Slash", k) == 1 and charUnit[3] == .26 or
			LibStub("SpellRange-1.0").IsSpellInRange("Backstab", k) == 1 and charUnit[3] == .27 or
			LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", k) == 1 and charUnit[3] == .28 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rockbiter", k) == 1 and charUnit[3] == .29 or
			LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", k) == 1 and charUnit[3] == .30 or
			LibStub("SpellRange-1.0").IsSpellInRange("Agony", k) == 1 and charUnit[3] == .31 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mortal Strike", k) == 1 and charUnit[3] == .32 or
			LibStub("SpellRange-1.0").IsSpellInRange("Bloodthirst", k) == 1 and charUnit[3] == .33 or
			LibStub("SpellRange-1.0").IsSpellInRange("Devastate", k) == 1 and charUnit[3] == .34 or
			LibStub("SpellRange-1.0").IsSpellInRange("Doom", k) == 1 and charUnit[3] == .35 or
			LibStub("SpellRange-1.0").IsSpellInRange("Incinerate", k) == 1 and charUnit[3] == .36) and
            UnitIsDead(k) == false and UnitAffectingCombat(k) then
                enemiesPlate = enemiesPlate + 1
            --print("what is k:",k,"Is ",v," In range ",LibStub("SpellRange-1.0").IsSpellInRange("Mongoose Bite", v)," Is unit dead :",UnitIsDead(v))
        
            end
        end
    end
    enemiesPlate = enemiesPlate/100
    
end
local function NameplateFrameUPDATE()
	activeEnemies()
	 TurnOnPlates()
	--TurnOnPlates()
	--print("Npc counT",enemiesPlate)
	raidSizeFrame.t:SetColorTexture(partySize, enemiesPlate, PlatesOn, alphaColor)
end

local function AddNameplate(unitID)
	local GUID = false
	for k,v in pairs(activeUnitPlates)do
		 activeUnitPlates[k] = nil
	end	
	for i=1, 30 do
		if	UnitGUID ("nameplate"..i) ~= nil and not UnitIsPlayer("nameplate".. i) then
			for k, v in pairs(activeUnitPlates) do
			--print("Nameplate :","nameplate"..i,"GUID",UnitGUID ("nameplate"..i)  )
				if v == UnitGUID ("nameplate"..i) then
					print("V== GUIDNameplate :","nameplate"..i,"GUID",UnitGUID ("nameplate"..i)  )
					GUID = true
				end
			end
			if GUID == false then
				--print("SET Nameplate :","nameplate"..i,"GUID",UnitGUID ("nameplate"..i)  )
				activeUnitPlates["nameplate"..i] = UnitGUID ("nameplate"..i)
				GUID = false
			end
		end
		GUID = false
	end
end
local function RemoveNameplate(unitID)
     local unitHP-- recycle the nameplate
	if unitHP == 0 or unitHP ==nil then
		activeUnitPlates[UnitGUID (unitID)] = nil
	end
end
local function ClearNamePlates()
	for k,v in pairs(activeUnitPlates)do
		if  k ~=UnitGUID("target") then 
			activeUnitPlates[k] = nil
		end 
	end	
end


local function register_unit(tbl, unit)
		table.insert(tbl, unit)
end
do
	for i = 5, partySize do
		register_unit(party_units, ("party%d"):format(i))
	end
	for	i = 1,30 do
		register_unit(raid_units, ("raid%d"):format(i))
	end
end

local function UdateRaidSizeFrame(self, event)
	partySize = GetNumGroupMembers() ;
	TurnOnPlates()
	partySize = partySize /100
	--print("Party Size: ",partySize)
	if partySize > .30 then
		partySize = .30
	end
	--print("Partyupdate :",partySize)
	--print("Name plates :", PlatesOn)
	raidSizeFrame.t:SetColorTexture(partySize, enemiesPlate, PlatesOn, alphaColor)
end

local function InitializeThree()
	
    local i = 0

	for i = 1, 4 do 
		raidBuff[i] = 1
		raidBufftime[i] =1
	end
		--print ("Initialising raid Health Frames")
	for i = 1, 20 do	
		raidHealthFrame[i] = CreateFrame("frame", "", parent)
		raidHealthFrame[i]:SetSize(size, size)
		raidHealthFrame[i]:SetPoint("TOPLEFT", size*(i-1), -size *18 )   --  row 1-20,  column 19
		raidHealthFrame[i].t = raidHealthFrame[i]:CreateTexture()        
		raidHealthFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		raidHealthFrame[i].t:SetAllPoints(raidHealthFrame[i])
		raidHealthFrame[i]:Show()
	end
	for i = 21, 30 do		
		raidHealthFrame[i] = CreateFrame("frame", "", parent)
		raidHealthFrame[i]:SetSize(size, size)
		raidHealthFrame[i]:SetPoint("TOPLEFT", size*(i-21), -size *19 )   --  row 1-10,  column 20
		raidHealthFrame[i].t = raidHealthFrame[i]:CreateTexture()        
		raidHealthFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		raidHealthFrame[i].t:SetAllPoints(raidHealthFrame[i])
		raidHealthFrame[i]:Show()
	end
		raidSizeFrame = CreateFrame("frame", "", parent)
		raidSizeFrame:SetSize(size, size)
		raidSizeFrame:SetPoint("TOPLEFT", size*(10), -size *19 )   --  row 11,  column 20
		raidSizeFrame.t = raidSizeFrame:CreateTexture()        
		raidSizeFrame.t:SetColorTexture(1, 1, 1, alphaColor)
		raidSizeFrame.t:SetAllPoints(raidSizeFrame)
		raidSizeFrame:Show()
		raidSizeFrame:SetScript("OnUpdate",NameplateFrameUPDATE)
		
	for i = 1, 4 do		
		RaidBuffFrame[i] = CreateFrame("frame", "", parent)
		RaidBuffFrame[i]:SetSize(size, size)
		RaidBuffFrame[i]:SetPoint("TOPLEFT", size*(10 + i), -size *19 )   --  row 12-15,  column 20
		RaidBuffFrame[i].t = RaidBuffFrame[i]:CreateTexture()        
		RaidBuffFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		RaidBuffFrame[i].t:SetAllPoints(RaidBuffFrame[i])
		RaidBuffFrame[i]:Show()
		RaidBuffFrame[i]:SetScript("OnUpdate", updateRaidBuff)
	end
	for i = 1, 5 do
		PlayerStatFrame[i] = CreateFrame("frame", "", parent)
		PlayerStatFrame[i]:SetSize(size, size)
		PlayerStatFrame[i]:SetPoint("TOPLEFT", size*(i-1), -size *20 )   --  row 1-4,  column 21
		PlayerStatFrame[i].t =PlayerStatFrame[i]:CreateTexture()        
		PlayerStatFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		PlayerStatFrame[i].t:SetAllPoints(PlayerStatFrame[i])
		PlayerStatFrame[i]:Show()
	end
		targetCastFrame = CreateFrame("frame", "", parent)
		targetCastFrame:SetSize(size, size);
		targetCastFrame:SetPoint("TOPLEFT", size * 4, -(size * 20))           -- column 4 row 21
		targetCastFrame.t = targetCastFrame:CreateTexture()        
		targetCastFrame.t:SetColorTexture(1, 1, 1, alphaColor)
		targetCastFrame.t:SetAllPoints(targetCastFrame)
		targetCastFrame:Show()	
		targetCastFrame:SetScript("OnUpdate", targetCastingupdate)
end
	

local function HealinEventHandler(self,event, unit, spellName, _, _, spellID)
    if event == "NAME_PLATE_UNIT_ADDED" then
		    AddNameplate(unit)
			activeEnemies()
    end
	if event == "UNIT_HEALTH_FREQUENT" then
		if (unitID ~= "player") then
			UpdateRaidIndicators(unit)
		end
	end
	if event == "UNIT_SPELLCAST_CHANNEL_START" or event == "UNIT_SPELLCAST_START"  then
			addtargetcast(spellID)
    end
	if event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_CHANNEL_STOP" then
       removetargetcast(spellID)
    end
	if event == "RAID_ROSTER_UPDATE" or event == "GROUP_ROSTER_UPDATE" then
	   UdateRaidSizeFrame()
    end
	if event == "UNIT_SPELL_HASTE" then
		HasteInfoUpdate()
	end
	if event == "UNIT_POWER" then
			UpdateMana()
	end
	if event == "PLAYER_ENTERING_WORLD"then
		TurnOnPlates()

	end
	if event == "PLAYER_REGEN_DISABLED"then 
		ClearNamePlates()
		CharRaceUpdate()
		Talents()
		UpdateMana()
		

	end
	if event == "PLAYER_REGEN_ENABLED"then 
		ClearNamePlates()
		activeEnemies()
	end
	
end
frame:SetScript("OnEvent",HealinEventHandler)
