-- VERSion 2.0
local Healingbuffs =  "Riptide"
local Race = {
	["Human"] = 0.01,
	["Dwarf"]= 0.02,
	["nightelf"]= 0.03,
	["Gnome"]= 0.04,
	["Draenei"]= 0.05,
	["Pandaren"]= 0.06,
	["Orc"]= 0.07,
	["Undead"]= 0.08,
	["Tauren"]= 0.09,
	["Troll"]= 0.10,
	["Blood Elf"]= 0.11,
	["Goblin"]= 0.12,
}
local Spec = {
	["Blood"] = 0.01,
	["Frost"] = 0.02,
	["Unholy"] =0.03,
	["Havoc"] = 0.04,
	["Vengeance"] =0.05,
	["Balance"] = 0.06,
	["Feral"] =0.07,
	["Guardian"] =0.08,
	["Restoration"] =0.09,
	["Beast Mastery"] = 0.10,
	["Marksmanship"] =0.11,
	["Survival"] = 0.12,
	["Arcane"] =0.13,
	["Fire"] = 0.14,
	["Frost"] =0.15,
	["Brewmaster"] = 0.16,
	["Mistweaver"] =0.17,
	["Windwalker"] = 0.18,
	["Holy"] = 0.19,
	["Protection"] = 0.20,
	["Retribution"] =0.21,
	["Discipline"] = 0.22,
	["HolyPriest"]=.23,
	["Shadow"] =0.24,
	["Assassination"] =0.25,
	["Outlaw"] =0.26,
	["Subtlety"] = 0.27,
	["Elemental"] = 0.28,
	["Enhancement"] = 0.29,
	["RestorationShaman"] = 0.30,
	["Affliction"] = 0.31,
	["Arms"] = 0.32,
	["Fury"] = 0.33,
	["Protection"] = 0.34,
	["Demonology"] = 0.35,
    ["Destruction"] = 0.36,
}

local activeUnitPlates = {}
local RaidBuffFrame = {}
local raidSizeFrame = nil
local PlayerStatFrame = {}
local targetInfoFrame = nil
local timerDBMFrames = {}
local PlatesOn = 0
local party_units = {}
local raid_units = {}
local raidheal_cache = {}
local raidHealthFrame = {}
local RaidRole = {}
local RaidRange = {}
local lasthp = {}
local castPCT = 0
local charUnit = {}
local Tier = {}
local lasthaste = 0
local hasteInfo = {}
local raidBuff = {}
local raidBufftime = {}
local partySize = 0
local setBonusFrame = nil

local frame = CreateFrame("frame", "", parent)
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterEvent("UNIT_HEALTH_FREQUENT")
frame:RegisterEvent("RAID_ROSTER_UPDATE")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterUnitEvent("UNIT_SPELL_HASTE","player")
frame:RegisterUnitEvent("UNIT_POWER","player")
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("CHAT_MSG_ADDON")
frame:RegisterUnitEvent("UNIT_HEALTH","player")
frame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
frame:RegisterUnitEvent("UNIT_TARGET","player")
frame:RegisterEvent("PLAYER_ENTER_COMBAT")
frame:RegisterEvent("PLAYER_LEAVE_COMBAT")
frame:RegisterEvent("PLAYER_CONTROL_LOST")
frame:RegisterEvent("PLAYER_CONTROL_GAINED")

local function updateFlag(self, event)
	if event == "PLAYER_CONTROL_GAINED" then
		flagFrame.t:SetColorTexture(0,0,0,alphaColor)
	end
	if event == "PLAYER_CONTROL_LOST" then
		flagFrame.t:SetColorTexture(1,0,0,alphaColor)
	end
end

local function HasteInfoUpdate()
	local ratingBonus = math.floor(GetHaste())
	if lasthaste == ratingBonus then return end
	lastehaste = ratingBonus
	hasteInfo[2] = 0
	if (ratingBonus * -1) > ratingBonus then
		HasteInfo[2] = 1
	end
	hasteInfo[1] = tonumber("0.0".. math.abs(ratingBonus))
	if (math.abs(ratingBonus) >= 10) then
		hasteInfo[1] = tonumber("0.".. math.abs(ratingBonus))
	end

end
local function UpdateMana()
		charUnit[1] = UnitPower("player",0) / UnitPowerMax("player",0)
		HasteInfoUpdate()
		PlayerStatFrame[4].t:SetColorTexture(hasteInfo[2], hasteInfo[1],charUnit[1], alphaColor)
end


local function Talents()
		AllSeven = false
		for i = 1, GetMaxTalentTier() do 
		talenetSelected = false
			for z = 1, 3 do 
				local  selected = select(4, GetTalentInfo(i, z,1))
				if(selected == true) then
					Tier[i] = z/100
					talenetSelected = true
				end
				if talenetSelected == false and z == 3 then
					Tier[i]=0
				end
			end
			if i == 7 then
				AllSeven = true 
			end
		end
	if not AllSeven then
		for i = GetMaxTalentTier(), 7 do
			Tier[i] = 0	
		end
	end
	PlayerStatFrame[1].t:SetColorTexture(Tier[1], Tier[2],Tier[3], alphaColor)
	PlayerStatFrame[2].t:SetColorTexture(Tier[4],Tier[5],Tier[6], alphaColor)
	PlayerStatFrame[3].t:SetColorTexture(Tier[7],charUnit[3],charUnit[2], alphaColor)
end

local function CharRaceUpdate()
	charUnit[2] = Race[UnitRace("player")]
	charUnit[3] = Spec[select(2, GetSpecializationInfo(GetSpecialization()))]
	
end


local function UnitIsPartyUnit(unit)
	--print("checking :", unit)
	for _, v in next, party_units do
		if unit == v then return true end
	end
end

local function UnitIsRaidUnit(unit)
	for _, v in next, raid_units do
		if unit == v then return true end
	end
end

local function HealthChangedEvent(unit)
	local h = UnitHealth(unit)
	if h==lasthp[unit] then return end
	lasthp[unit]=h
	local m = UnitHealthMax(unit);
	h = (h / m)
	raidheal_cache[unit] = h
end

local function RangeCheck(unit)
	if LibStub("SpellRange-1.0").IsSpellInRange("Healing Wave", unit) == 1 then
		RaidRange[unit] = 1;
	else
		RaidRange[unit] = .5;
	end
end

local function RaidRoleCheck(unit)
	if UnitGroupRolesAssigned(unit) == "TANK" then
		RaidRole[unit] = 1;
	elseif UnitGroupRolesAssigned(unit) == "HEALER" then
		RaidRole[unit] = .5;
	else
		RaidRole[unit] = 0;
	end
end

local function UpdateRaidIndicators(unit)
	if UnitIsRaidUnit(unit) or UnitIsPartyUnit(unit) then
		if UnitInParty ("player") and not UnitInRaid ("player") then
		--print(unit,"needs heals")
			for i, key in pairs(party_units) do
				if key == unit then
					HealthChangedEvent(unit)
					RangeCheck(unit)
					RaidRoleCheck(unit)
					--print(unit, "is at :", raidheal_cache[unit])
					raidHealthFrame[i].t:SetColorTexture(raidheal_cache[unit], RaidRange[unit], RaidRole[unit], alphaColor)
				end	
			end
		end
		if UnitInRaid ("player") then 
			for i, key in pairs(raid_units) do
				if key == unit then
					HealthChangedEvent(unit)
					RangeCheck(unit)
					RaidRoleCheck(unit)
				
					--print(unit, "is at :", raidheal_cache[unit], " and At : ", i)
					raidHealthFrame[i].t:SetColorTexture(raidheal_cache[unit], RaidRange[unit], RaidRole[unit], alphaColor)
				end	
			end
		end
		if not UnitInRaid ("player") and not UnitInParty ("player") then
			for i = 1, 30 do
				raidHealthFrame[i].t:SetColorTexture(1, 0, 0, alphaColor)
			end
		end
	end
end

local function updateTotemsFrame()
	Totemsframe = 0
	TotemDuration = 0 
	for i = 1, 4 do
		haveTotem, name, startTime, duration, icon = GetTotemInfo(i)
		local Quesatime =  startTime + duration
		if haveTotem then
			if (name == "Spirit Wolf" or name == "Totem Mastery")
			and(startTime + duration - GetTime() > 1.5 ) then
				Totemsframe = 1;
				TotemDuration = startTime + duration - GetTime()
			end
		end
	end
	totemsFrame.t:SetColorTexture(Totemsframe, TotemDuration,0, alphaColor)
	
end


local function UpdateRaidBuffIndicators(unit)
		if select(7, UnitBuff(unit, Healingbuffs, "player")) == nil  then return end
		UpdateRaidBuffslot(unit,expires)
end

local function UpdateRaidBuffslot(unit,expires)
	for i = 1, 4 do 
		if raidBuff[i] == 0 then
			local slot = string.match (unit, "%d+")
			UpdateBuffTime(unit,expires,i)
			if i >= 10 then
				raidBuff[i] = tonumber("0." .. slot)
			else 
				raidBuff[i] = tonumber("0.0" .. slot)
			end
		end
	end
end

local function UpdateBuffTime(unit,expires,location)
	local remainingTime = math.floor(expires -  GetTime() + 0.5)
	if(remainingTime >= 10) then
		raidBufftime[i] = tonumber("0."..remainingTime);
	else
		raidBufftime[i] = tonumber("0.0"..remainingTime);
	end
end

local function updateRaidBuff(self, event)
	if not UnitInRaid ("player") and  UnitInParty ("player") then
		for key, _ in pairs(party_units) do
			UpdateRaidBuffIndicators(key)
		end
	end	
	if UnitInRaid ("player") then
		for key, _ in pairs(raid_units) do
			UpdateRaidBuffIndicators(key)
		end
	end
	for i=1, 4 do 
		if raidBuff[i] ~= nil then
			RaidBuffFrame[i].t:SetColorTexture(raidBuff[i], 1, raidBufftime[i], alphaColor)
			RaidBuffFrame[i].t:SetAllPoints(false)
		else
			RaidBuffFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
			RaidBuffFrame[i].t:SetAllPoints(false)
			raidBuff[i] = nil
			raidBufftime[i] = nil
		end
	end
end
local function TurnOnPlates()
	if GetCVar("nameplateShowEnemies") == "1" then
		PlatesOn = 1
	else
		PlatesOn = 0
	end
end
local enemiesPlate = 0
local function activeEnemies()
    enemiesPlate = 0
    for k, v in pairs(activeUnitPlates) do
        if v ~= nil then
            if UnitCanAttack("player", k) 
            and (LibStub("SpellRange-1.0").IsSpellInRange("Death Strike", k) == 1 and charUnit[3] == .01 or
			LibStub("SpellRange-1.0").IsSpellInRange("Frost Strike", k) == 1 and charUnit[3] == .02 or
			LibStub("SpellRange-1.0").IsSpellInRange("Festering Strike", k) == 1 and charUnit[3] == .03 or
			LibStub("SpellRange-1.0").IsSpellInRange("Demon's Bite", k) == 1 and charUnit[3] == .04 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shear", k) == 1 and charUnit[3] == .05 or
			LibStub("SpellRange-1.0").IsSpellInRange("Solar Wrath", k) == 1 and charUnit[3] == .06 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shred", k) == 1 and charUnit[3] == .07 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mangle", k) == 1 and charUnit[3] == .08 or
			LibStub("SpellRange-1.0").IsSpellInRange("Solar Wrath", k) == 1 and charUnit[3] == .09 or
			LibStub("SpellRange-1.0").IsSpellInRange("Counter Shot", k) == 1 and charUnit[3] == .10 or
			LibStub("SpellRange-1.0").IsSpellInRange("Counter Shot", k) == 1 and charUnit[3] == .11 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mongoose Bite", k) == 1 and charUnit[3] == .12 or
			LibStub("SpellRange-1.0").IsSpellInRange("Arcane Blast", k) == 1 and charUnit[3] == .13 or
			LibStub("SpellRange-1.0").IsSpellInRange("Fireball", k) == 1 and charUnit[3] == .14 or
			LibStub("SpellRange-1.0").IsSpellInRange("Frostbolt", k) == 1 and charUnit[3] == .15 or
			LibStub("SpellRange-1.0").IsSpellInRange("Blackout Strike", k) == 1 and charUnit[3] == .16 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rising Sun Kick", k) == 1 and charUnit[3] == .17 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rising Sun Kick", k) == 1 and charUnit[3] == .18 or
			LibStub("SpellRange-1.0").IsSpellInRange("Crusader Strike", k) == 1 and charUnit[3] == .19 or
			LibStub("SpellRange-1.0").IsSpellInRange("Shield of the Righteous", k) == 1 and charUnit[3] == .20 or
			LibStub("SpellRange-1.0").IsSpellInRange("Crusader Strike", k) == 1 and charUnit[3] == .21 or
			LibStub("SpellRange-1.0").IsSpellInRange("Penance", k) == 1 and charUnit[3] == .22 or
			
			LibStub("SpellRange-1.0").IsSpellInRange("Smite", k) == 1 and charUnit[3] == .23 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mind Blast", k) == 1 and charUnit[3] == .24 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mutilate", k) == 1 and charUnit[3] == .25 or
			LibStub("SpellRange-1.0").IsSpellInRange("Saber Slash", k) == 1 and charUnit[3] == .26 or
			LibStub("SpellRange-1.0").IsSpellInRange("Backstab", k) == 1 and charUnit[3] == .27 or
			LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", k) == 1 and charUnit[3] == .28 or
			LibStub("SpellRange-1.0").IsSpellInRange("Rockbiter", k) == 1 and charUnit[3] == .29 or
			LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", k) == 1 and charUnit[3] == .30 or
			LibStub("SpellRange-1.0").IsSpellInRange("Agony", k) == 1 and charUnit[3] == .31 or
			LibStub("SpellRange-1.0").IsSpellInRange("Mortal Strike", k) == 1 and charUnit[3] == .32 or
			LibStub("SpellRange-1.0").IsSpellInRange("Bloodthirst", k) == 1 and charUnit[3] == .33 or
			LibStub("SpellRange-1.0").IsSpellInRange("Devastate", k) == 1 and charUnit[3] == .34 or
			LibStub("SpellRange-1.0").IsSpellInRange("Doom", k) == 1 and charUnit[3] == .35 or
			LibStub("SpellRange-1.0").IsSpellInRange("Incinerate", k) == 1 and charUnit[3] == .36) and
            UnitIsDead(k) == false and UnitAffectingCombat(k) then
                enemiesPlate = enemiesPlate + 1
            --print("what is k:",k,"Is ",v," In range ",LibStub("SpellRange-1.0").IsSpellInRange("Mongoose Bite", v)," Is unit dead :",UnitIsDead(v))
        
            end
        end
    end
    enemiesPlate = enemiesPlate/100
    
end
local function NameplateFrameUPDATE()
	activeEnemies()
	TurnOnPlates()
	--TurnOnPlates()
	--print("Npc counT",enemiesPlate)
	raidSizeFrame.t:SetColorTexture(partySize, enemiesPlate, PlatesOn, alphaColor)
end

local function AddNameplate(unitID)
	local GUID = false
	for k,v in pairs(activeUnitPlates)do
		 activeUnitPlates[k] = nil
	end	
	for i=1, 30 do
		if	UnitGUID ("nameplate"..i) ~= nil and not UnitIsPlayer("nameplate".. i) then
			for k, v in pairs(activeUnitPlates) do
			--print("Nameplate :","nameplate"..i,"GUID",UnitGUID ("nameplate"..i)  )
				if v == UnitGUID ("nameplate"..i) then
					GUID = true
				end
			end
			if GUID == false then
				--print("SET Nameplate :","nameplate"..i,"GUID",UnitGUID ("nameplate"..i)  )
				activeUnitPlates["nameplate"..i] = UnitGUID ("nameplate"..i)
				GUID = false
			end
		end
		GUID = false
	end
end
local function ClearNamePlates()
	for k,v in pairs(activeUnitPlates)do
		if  k ~=UnitGUID("target") then 
			activeUnitPlates[k] = nil
		end 
	end	
end


local function register_unit(tbl, unit)
		table.insert(tbl, unit)
end
do
	for i = 1, 5 do
		register_unit(party_units, ("party%d"):format(i))
	end
	for	i = 1,30 do
		register_unit(raid_units, ("raid%d"):format(i))
	end
end
local invSlots = {
1,3,5,7,10,15
}
local setItems = {
	--shaman
	138343, 138348, 138372, 138346, 138341, 138345
}
local function updateSetBonus()
	count = 0
	for _, v in pairs(invSlots) do
		itemID = GetInventoryItemID("player", v);
		for _,z in pairs(setItems) do
			if(itemID == z)then
			--print(v, " ", z)
				count= count +1
			end
		end

	end
	setBonusFrame.t:SetColorTexture(count/100, 0, 0, alphaColor)
end

local function UdateRaidSizeFrame(self, event)
	partySize = GetNumGroupMembers() ;
	TurnOnPlates()
	partySize = partySize /100
	--print("Party Size: ",partySize)
	if partySize > .30 then
		partySize = .30
	end
	--print("Partyupdate :",partySize)
	--print("Name plates :", PlatesOn)
	raidSizeFrame.t:SetColorTexture(partySize, enemiesPlate, PlatesOn, alphaColor)
end
local DBMTIMER = {}

local function updateDBMFrames(elapsed)
	if(pullvalue and tickerdbm >= 0) then
		tickerdbm = tickerdbm - elapsed
		timerDBMFrames.t:SetColorTexture( 1,tickerdbm/10,0, alphaColor)
	else
		timerDBMFrames.t:SetColorTexture( 0,0,0, alphaColor)
	end
end
local timer 
local function DBMPull(prefix,msg,sender)
	_, _,_,_,_, _,_, instanceMapID, _ = GetInstanceInfo()
	if prefix == "D4" and select(1,strsplit("\t", msg)) == "PT"
    and (UnitInRaid(Ambiguate(sender, "short")) or UnitInParty ( Ambiguate (sender, "short") ) )
   	and tonumber ( select(3, strsplit("\t", msg) ) ) == instanceMapID  then
		local time = select(2,strsplit("\t", msg) )
		time =  tonumber(time)
		if time ~= 0 then
			print("DBM pull timer")
			tickerdbm = time
			pullvalue = true
		end
		if time == 0 then
			tickerdbm = time
			pullvalue = false
		end

	end
end
local function updatetargetInfoFrame()
	targetexist = 0
	rangetargetexist = 0
	if UnitExists("target") and UnitAffectingCombat("target") then
		if	LibStub("SpellRange-1.0").IsSpellInRange("Rockbiter", "target") == 1 and charUnit[3] == .29  then
			targetexist = 1
		end
		if LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", "target") == 1 and charUnit[3] == .28 then
			targetexist = 1
		end
	end
	if UnitExists("mouseover") and UnitAffectingCombat("mouseover") and LibStub("SpellRange-1.0").IsSpellInRange("Lightning Bolt", "mouseover") == 1 then
			rangetargetexist = 1
	end
	
	--print("Info ", targetexist, " ", rangetargetexist )
	targetInfoFrame.t:SetColorTexture(targetexist,rangetargetexist, 0 ,alphaColor)
end
local function InitializeThree()
	for i = 1, 4 do 
		raidBuff[i] = 1
		raidBufftime[i] =1
	end
		--print ("Initialising raid Health Frames")
	for i = 1, 20 do	
		raidHealthFrame[i] = CreateFrame("frame", "", parent)
		raidHealthFrame[i]:SetSize(size, size)
		raidHealthFrame[i]:SetPoint("TOPLEFT", size*(i-1), -size *18 )   --  row 1-20,  column 19
		raidHealthFrame[i].t = raidHealthFrame[i]:CreateTexture()        
		raidHealthFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		raidHealthFrame[i].t:SetAllPoints(raidHealthFrame[i])
		raidHealthFrame[i]:Show()
	end
	for i = 21, 30 do		
		raidHealthFrame[i] = CreateFrame("frame", "", parent)
		raidHealthFrame[i]:SetSize(size, size)
		raidHealthFrame[i]:SetPoint("TOPLEFT", size*(i-21), -size *19 )   --  row 1-10,  column 20
		raidHealthFrame[i].t = raidHealthFrame[i]:CreateTexture()        
		raidHealthFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		raidHealthFrame[i].t:SetAllPoints(raidHealthFrame[i])
		raidHealthFrame[i]:Show()
	end
		raidSizeFrame = CreateFrame("frame", "", parent)
		raidSizeFrame:SetSize(size, size)
		raidSizeFrame:SetPoint("TOPLEFT", size*(10), -size *19 )   --  row 11,  column 20
		raidSizeFrame.t = raidSizeFrame:CreateTexture()        
		raidSizeFrame.t:SetColorTexture(1, 1, 1, alphaColor)
		raidSizeFrame.t:SetAllPoints(raidSizeFrame)
		raidSizeFrame:Show()
		raidSizeFrame:SetScript("OnUpdate",NameplateFrameUPDATE)
		
	for i = 1, 4 do		
		RaidBuffFrame[i] = CreateFrame("frame", "", parent)
		RaidBuffFrame[i]:SetSize(size, size)
		RaidBuffFrame[i]:SetPoint("TOPLEFT", size*(10 + i), -size *19 )   --  row 12-15,  column 20
		RaidBuffFrame[i].t = RaidBuffFrame[i]:CreateTexture()        
		RaidBuffFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		RaidBuffFrame[i].t:SetAllPoints(RaidBuffFrame[i])
		RaidBuffFrame[i]:Show()
		
	end
	for i = 1, 5 do
		PlayerStatFrame[i] = CreateFrame("frame", "", parent)
		PlayerStatFrame[i]:SetSize(size, size)
		PlayerStatFrame[i]:SetPoint("TOPLEFT", size*(i-1), -size *20 )   --  row 1-4,  column 21
		PlayerStatFrame[i].t =PlayerStatFrame[i]:CreateTexture()        
		PlayerStatFrame[i].t:SetColorTexture(1, 1, 1, alphaColor)
		PlayerStatFrame[i].t:SetAllPoints(PlayerStatFrame[i])
		PlayerStatFrame[i]:Show()
	end
		timerDBMFrames = CreateFrame("frame", "", parent)
		timerDBMFrames:SetSize(size, size);
		timerDBMFrames:SetPoint("TOPLEFT", size * 5, -(size * 20))           -- column 6 row 21
		timerDBMFrames.t = timerDBMFrames:CreateTexture()        
		timerDBMFrames.t:SetColorTexture(0, 0, 0, alphaColor)
		timerDBMFrames.t:SetAllPoints(timerDBMFrames)
		timerDBMFrames:Show()	


		totemsFrame = CreateFrame("frame", "", parent)
		totemsFrame:SetSize(size, size);
		totemsFrame:SetPoint("TOPLEFT", size * 6, -(size * 20))           -- column 7 row 21
		totemsFrame.t = totemsFrame:CreateTexture()        
		totemsFrame.t:SetColorTexture(0, 0, 0, alphaColor)
		totemsFrame.t:SetAllPoints(totemsFrame)
		totemsFrame:Show()

		targetInfoFrame = CreateFrame("frame", "", parent)
		targetInfoFrame:SetSize(size, size);
		targetInfoFrame:SetPoint("TOPLEFT", size * 7, -(size * 20))           -- column 8 row 21
		targetInfoFrame.t = targetInfoFrame:CreateTexture()        
		targetInfoFrame.t:SetColorTexture(0, 0, 0, alphaColor)
		targetInfoFrame.t:SetAllPoints(targetInfoFrame)
		targetInfoFrame:Show()

		setBonusFrame = CreateFrame("frame", "", parent)
		setBonusFrame:SetSize(size, size);
		setBonusFrame:SetPoint("TOPLEFT", size * 8, -(size * 20))           -- column 9 row 21
		setBonusFrame.t = setBonusFrame:CreateTexture()        
		setBonusFrame.t:SetColorTexture(0, 0, 0, alphaColor)
		setBonusFrame.t:SetAllPoints(setBonusFrame)
		setBonusFrame:Show()
end

local function HealinEventHandler(self,event, ...)
    if event == "NAME_PLATE_UNIT_ADDED" then
		    AddNameplate(select(1,...))
			activeEnemies()
    end
	if event == "UNIT_HEALTH_FREQUENT" then
	
		if (select(1,...) ~= "player") then
			UpdateRaidIndicators(select(1,...))
		end
	end

	if event == "RAID_ROSTER_UPDATE" or event == "GROUP_ROSTER_UPDATE" then
	   UdateRaidSizeFrame()
    end
	if event == "UNIT_SPELL_HASTE" then
		HasteInfoUpdate()
		updateHaste()
	end
	if event == "UNIT_POWER" then
		UpdateMana()
		updatePower()
		updateUnitPower()
	end
	if event == "PLAYER_ENTERING_WORLD"then
		CharRaceUpdate()
		Talents()
		TurnOnPlates()
		updateSetBonus()
	end
	if event == "PLAYER_REGEN_DISABLED"then 
		ClearNamePlates()
		CharRaceUpdate()
		Talents()
		UpdateMana()
		updateCombat()
		updateSetBonus()
	end
	if event == "PLAYER_REGEN_ENABLED"then 
		ClearNamePlates()
		activeEnemies()
		updateCombat()
	end
	if event == "PLAYER_EQUIPMENT_CHANGED" then
		updateSetBonus()
	end
	if event == "CHAT_MSG_ADDON"then 
		--select(1,...) --prefix
		--select(2,...) --msg
		--select(4,...) sender
		DBMPull(select(1,...),select(2,...),select(4,...))
	end

	if event == "UNIT_HEALTH" then
		updateHealth()
		updateTargetHealth()
	end
	if event == "UNIT_TARGET" then
		updateIsFriendly()
		hasTarget()
		updateUnitIsVisible()
		updateIsPlayer()
	end
	if event == "PLAYER_ENTER_COMBAT" or event == "PLAYER_LEAVE_COMBAT" then
		AutoAtacking()
	end

end

local GlobalTimer = 0
local function onUpDateFunction(self,elapsed)
		if GlobalTimer <= 0 then
			GlobalTimer = .10
		else
			GlobalTimer = GlobalTimer - elapsed
		end
		
		if GlobalTimer <= .01 then
			updateRaidBuff()
			updateTotemsFrame()
			updatetargetInfoFrame()
			updateDBMFrames(elapsed)
			updatePlayerIsCasting()
			updateTargetIsCasting()
						
		    if (classIndex == 6 or                                  -- DeathKnight   
				classIndex == 3 or                                  -- Hunter
				classIndex == 9 or                                  -- Warlock
				classIndex == 8 or                                  -- Mage
				classIndex == 7)                                    -- Shaman (Enh. Needs it for Wolves)
				then
					updateUnitPet()
					updatePetHealth()
					updateWildPetsFrame()
					updateMyPetBuffs()

			end
			updateSpellCooldowns()
			updateSpellInRangeFrames()
			updateTargetDebuffs()
			updateSpellCharges()
			updateTargetBuffs()
			PlayerNotMove()
			updateTargetCurrentSpell()
			updateArena1Spell()
			updateArena2Spell()
			updateArena3Spell()
			updateMyBuffs()
			updateItemCooldowns()
			updatePlayerDebuffs()
			updateIsSpellOverlayedFrames()
			 GlobalTimer= .10
		end
end	
frame:SetScript("OnEvent",HealinEventHandler)
frame:SetScript("OnUpdate",onUpDateFunction)
